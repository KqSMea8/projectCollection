// 方法名统一定义，可看个人喜好，可以不必抽出
export const ADD = 'ADD'
export const REDUCE = 'REDUCE'
export const ADDBASE = 'ADDBASE'
export const REMOVEBASE = 'REMOVEBASE'
export const BREAD = 'BREAD'
export const CHANGE = 'CHANGE'
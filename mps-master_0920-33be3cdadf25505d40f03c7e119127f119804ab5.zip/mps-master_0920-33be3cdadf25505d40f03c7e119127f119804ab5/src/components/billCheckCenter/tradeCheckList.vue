<template>
  <div>
    <!-- html这里开始 -->


  </div>
</template>

<script>
import { Message } from 'element-ui' //element Message 组件引入

export default {
  data () {
    return {
      
    }
  },

  created: function () {
      
  },

  methods: {
     
  }
}

</script>

<style scoped>

</style>

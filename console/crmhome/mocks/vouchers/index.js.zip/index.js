this.config = {
  root: 'http://crmhome-d5752.alipay.net',
}
module.exports = {
  'GET /promo/conponsVerify/shopsQuery.json': function(req, res) { //查询店铺
    res.json({
      "resultMsg": "",
      "result": "true",
      "shopCountGroupByCityVO": [
		{
			"cityCode": "320400",
			"cityName": "常州市",
			"leafCount": 2,
			"shopCount": 2,
			"shops": []
		},
		{
			"cityCode": "621100",
			"cityName": "定西市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "120100",
			"cityName": "天津市",
			"leafCount": 2,
			"shopCount": 2,
			"shops": []
		},
		{
			"cityCode": "500100",
			"cityName": "重庆市",
			"leafCount": 7,
			"shopCount": 7,
			"shops": []
		},
		{
			"cityCode": "110100",
			"cityName": "北京市",
			"leafCount": 16,
			"shopCount": 16,
			"shops": []
		},
		{
			"cityCode": "350900",
			"cityName": "宁德市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "110200",
			"cityName": "",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "330100",
			"cityName": "杭州市",
			"leafCount": 82,
			"shopCount": 82,
			"shops": []
		},
		{
			"cityCode": "320100",
			"cityName": "南京市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "340800",
			"cityName": "安庆市",
			"leafCount": 41,
			"shopCount": 41,
			"shops": []
		},
		{
			"cityCode": "340300",
			"cityName": "蚌埠市",
			"leafCount": 5,
			"shopCount": 5,
			"shops": []
		},
		{
			"cityCode": "460200",
			"cityName": "三亚市",
			"leafCount": 2,
			"shopCount": 2,
			"shops": []
		},
		{
			"cityCode": "230800",
			"cityName": "佳木斯市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "420800",
			"cityName": "荆门市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "340700",
			"cityName": "铜陵市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "SH",
			"cityName": "",
			"leafCount": 8,
			"shopCount": 8,
			"shops": []
		},
		{
			"cityCode": "280800",
			"cityName": "",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "310100",
			"cityName": "上海市",
			"leafCount": 48,
			"shopCount": 48,
			"shops": []
		},
		{
			"cityCode": "310000",
			"cityName": "上海",
			"leafCount": 2,
			"shopCount": 2,
			"shops": []
		},
		{
			"cityCode": "340100",
			"cityName": "合肥市",
			"leafCount": 2,
			"shopCount": 2,
			"shops": []
		},
		{
			"cityCode": "511700",
			"cityName": "达州市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "350800",
			"cityName": "龙岩市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "810013",
			"cityName": "北区",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "350700",
			"cityName": "南平市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "450600",
			"cityName": "防城港市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "820100",
			"cityName": "",
			"leafCount": 11,
			"shopCount": 11,
			"shops": []
		},
		{
			"cityCode": "360400",
			"cityName": "九江市",
			"leafCount": 20,
			"shopCount": 20,
			"shops": []
		},
		{
			"cityCode": "422800",
			"cityName": "恩施土家族苗族自治州",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "341600",
			"cityName": "亳州市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "820200",
			"cityName": "",
			"leafCount": 3,
			"shopCount": 3,
			"shops": []
		},
		{
			"cityCode": "990100",
			"cityName": "",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		},
		{
			"cityCode": "530700",
			"cityName": "丽江市",
			"leafCount": 16,
			"shopCount": 16,
			"shops": []
		},
		{
			"cityCode": "441900",
			"cityName": "东莞市",
			"leafCount": 1,
			"shopCount": 1,
			"shops": []
		}
	],
      "status": "succeed"
    });
  },
  'GET /promo/conponsVerify/getShopsByCityForNewCamp.json': function(req, res) { //查询相应城市门店
    this.request = {
      cityCode: '320400',
    }
    res.json({
      "shopComps": [
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "6187932058275994101",
          "shopName": "为了储蓄卡20"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015050600077000000000081882",
          "shopName": "海底捞"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015122200077000000002392189",
          "shopName": "寻味馆(寻味馆)"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015042300077000000000011486",
          "shopName": "开心4"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015081900077000000001432263",
          "shopName": "123"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015122300077000000002392214",
          "shopName": "咖啡格子(咖啡格子)"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015121600077000000002382221",
          "shopName": "123"
        },
        {
          "categoryId": "",
          "cityCode": "500100",
          "extInfo": {},
          "shopId": "2015122300077000000002392211",
          "shopName": "锅快餐(锅快餐)"
        },
        {
          "categoryId": "",
          "cityCode": "110200",
          "extInfo": {},
          "shopId": "2016021800077000000002598080",
          "shopName": "pcpl021804(add04)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000963107",
          "shopName": "yuanhao49015(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016083100077000000003397920",
          "shopName": "丽人美甲（泛行业）"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015121000077000000002378296",
          "shopName": "caffee2(长江路店3)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015060100077000000000463213",
          "shopName": "小纨五折抢测试啊测试(啦啦啦)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051300077000000000115954",
          "shopName": "肯德基(万塘路店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410065",
          "shopName": "黄龙时代广场美食广场"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016021800077000000002598077",
          "shopName": "pcpl021801(add01)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000947983",
          "shopName": "yuanhao24252(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051300077000000000115956",
          "shopName": "aaa"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015052600077000000000273597",
          "shopName": "小纨测试折扣(阿斯顿范德萨)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015101200077000000001863409",
          "shopName": "商超"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845017",
          "shopName": "星巴克百脑汇(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050500077000000000073178",
          "shopName": "霍格测试0008_no brand"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050600077000000000081629",
          "shopName": "我来测试一下1"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016061400077000000003213138",
          "shopName": "小牛牛2"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845028",
          "shopName": "星巴克百脑汇9(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845027",
          "shopName": "星巴克百脑汇8(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016081800077000000003355813",
          "shopName": "cc123丽人(订单)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845025",
          "shopName": "星巴克百脑汇6(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050400077000000000060150",
          "shopName": "卡卡西9(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845029",
          "shopName": "星巴克百脑汇10(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845026",
          "shopName": "星巴克百脑汇7(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845024",
          "shopName": "星巴克百脑汇4(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845030",
          "shopName": "星巴克百脑汇11(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845020",
          "shopName": "星巴克百脑汇3(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016051300077000000003176732",
          "shopName": "测试测试(打我打我)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016090900077000000003410059",
          "shopName": "DIY美甲店(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845023",
          "shopName": "星巴克百脑汇1(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016090900077000000003410057",
          "shopName": "红磨坊003(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050400077000000000060123",
          "shopName": "卡卡西1(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015080600077000000001419143",
          "shopName": "haidilao"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845021",
          "shopName": "星巴克百脑汇2(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000955545",
          "shopName": "yuanhao16731(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845032",
          "shopName": "星巴克百脑汇13(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015052800077000000000430848",
          "shopName": "小纨测试native商家详情啦啦啦(三大发大水)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845031",
          "shopName": "星巴克百脑汇12(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015063000077000000001245557",
          "shopName": "肯德基(万达)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016031600077000000002598471",
          "shopName": "纯纯测试门店"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000968126",
          "shopName": "yuanhao37345(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050400077000000000055188",
          "shopName": "万达8(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000943068",
          "shopName": "yuanhao11350(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015063000077000000001245556",
          "shopName": "肯德基(拱墅万达店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015063000077000000001245554",
          "shopName": "肯德基(拱墅万达店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015043000077000000000033296",
          "shopName": "董小姐美食之家wowwowqq1"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015043000077000000000033297",
          "shopName": "董小姐美食之家wowwowqq2"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030100077000000002737616",
          "shopName": "dxc-1(11111)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015042900077000000000024788",
          "shopName": "董小姐美食之家hahahah1"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050200077000000000047521",
          "shopName": "再次测试淘点2967(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051900077000000000178374",
          "shopName": "小纨是来测试门店的长度超过10个字的情况(西湖店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050400077000000000060639",
          "shopName": "卡卡西124(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015052800077000000000453784",
          "shopName": "小纨测试停车位(三的发送到范德萨)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000943856",
          "shopName": "yuanhao11379(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410068",
          "shopName": "肯德基1235(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410067",
          "shopName": "泛行业美甲店(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051300077000000000115520",
          "shopName": "肯德基(万塘路店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015121000077000000002372798",
          "shopName": "caffee(长江路店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050100077000000000039334",
          "shopName": "小张张同学家开的牛肉店哇哈哈(门店1)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015061600077000000000952833",
          "shopName": "yuanhao29154(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015052800077000000000453717",
          "shopName": "小纨测试五折抢的折扣啦啦(撒旦法第三方)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015042800077000000000023777",
          "shopName": "董小姐美食之家哈哈aaaa2"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015050400077000000000054986",
          "shopName": "格瓦拉6(店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016090900077000000003410060",
          "shopName": "华仔美发店010(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016102800077000000003441355",
          "shopName": "瑾瑾门店美容美发(03店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016102800077000000003441353",
          "shopName": "瑾瑾门店超长超长超长超长超长超长超长超长(01店丽人超长超长超长超长超长超长超长超长)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016030800077000000002598430",
          "shopName": "testff"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011500077000000002425081",
          "shopName": "11(222)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020300077000000002597914",
          "shopName": "tsesffs"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030400077000000002845022",
          "shopName": "星巴克百脑汇5(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015101000077000000001863403",
          "shopName": "Test(test)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015122300077000000002392194",
          "shopName": "猪脚粉(v)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011800077000000002425088",
          "shopName": "danliu4(danliu4)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016022900077000000002749085",
          "shopName": "liudan(test)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123000077000000002414373",
          "shopName": "1230服务商已上架未绑定—批量(不勾选4)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016031700077000000002598592",
          "shopName": "服务01(pl01)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015122200077000000002392188",
          "shopName": "实惠餐馆(实惠餐馆)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015122400077000000002399892",
          "shopName": "12312(12323)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016031600077000000002598583",
          "shopName": "testfsfsdfs"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011800077000000002425087",
          "shopName": "danliu3(danliu3)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020200077000000002597886",
          "shopName": "这小子name(这小子)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016021800077000000002598079",
          "shopName": "pcpl021802(add02)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425068",
          "shopName": "这小子"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016031600077000000002598477",
          "shopName": "testfsfdf"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415464",
          "shopName": "服务已上未绑3(勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123000077000000002414372",
          "shopName": "1230服务商已上架未绑定—批量(勾选3)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415463",
          "shopName": "服务已上绑它1(不勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016030700077000000002598428",
          "shopName": "test01"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425071",
          "shopName": "这小子003"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123000077000000002414368",
          "shopName": "1230服务商已上架未绑定(不勾选1)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123000077000000002414370",
          "shopName": "1230服务商已上架未绑定(勾选2)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425066",
          "shopName": "这小子"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415465",
          "shopName": "服务已上绑它1(勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016030800077000000002598431",
          "shopName": "testff01"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015122800077000000002382229",
          "shopName": "1228服务商已上架已绑定(不勾选01)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016030700077000000002880343",
          "shopName": "zxz(zxz)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415462",
          "shopName": "服务已上已绑2(不勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020300077000000002597913",
          "shopName": "tsfsf"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425070",
          "shopName": "限制002"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415467",
          "shopName": "服已上未绑(不勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425067",
          "shopName": "这小子"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016011400077000000002425069",
          "shopName": "限制"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020300077000000002597912",
          "shopName": "海底(海底)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2015123100077000000002415466",
          "shopName": "服务已上已绑2(勾选)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016030900077000000002930309",
          "shopName": "zxz(zxz)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016010800077000000002425009",
          "shopName": "sadasdggggjjak(sdfkkkekjndhhd)"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020300077000000002597915",
          "shopName": "tsesfsdf"
        },
        {
          "categoryId": "",
          "cityCode": "340800",
          "extInfo": {},
          "shopId": "2016020300077000000002597916",
          "shopName": "testsf"
        },
        {
          "categoryId": "",
          "cityCode": "460200",
          "extInfo": {},
          "shopId": "2016011900077000000002467837",
          "shopName": "TR_test001(支付宝总店)"
        },
        {
          "categoryId": "",
          "cityCode": "340700",
          "extInfo": {},
          "shopId": "2015052600077000000000273592",
          "shopName": "dsadas"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2015052000077000000000182141",
          "shopName": "shop_1432102089259"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2016101800077000000003436501",
          "shopName": "NB店铺316397"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2016111200077000000003447317",
          "shopName": "NB店铺391900"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2016101000077000000003421296",
          "shopName": "NB店铺78361"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2015110700077000000002125058",
          "shopName": "NB店铺670734"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2016101800077000000003436500",
          "shopName": "NB店铺132483"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2015051300077000000000117126",
          "shopName": "shop_1431509411186"
        },
        {
          "categoryId": "",
          "cityCode": "SH",
          "extInfo": {},
          "shopId": "2015112000077000000002292910",
          "shopName": "NB店铺656923"
        },
        {
          "categoryId": "",
          "cityCode": "511700",
          "extInfo": {},
          "shopId": "2016010600077000000002424977",
          "shopName": "A(Bbb)"
        },
        {
          "categoryId": "",
          "cityCode": "810013",
          "extInfo": {},
          "shopId": "2016021800077000000002598078",
          "shopName": "pcpl021805(add05)"
        },
        {
          "categoryId": "",
          "cityCode": "450600",
          "extInfo": {},
          "shopId": "2015122400077000000002399891",
          "shopName": "服务商已上架未绑定(勾选002)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015051200077000000000109858",
          "shopName": "五道口(26F分店)"
        },
        {
          "categoryId": "",
          "cityCode": "350700",
          "extInfo": {},
          "shopId": "2015042400077000000000012642",
          "shopName": "开心6"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122200077000000002392191",
          "shopName": "珍奶工坊(珍奶工坊)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122200077000000002392190",
          "shopName": "实惠餐馆(实惠餐馆)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122200077000000002392192",
          "shopName": "3快餐(寻味馆)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122300077000000002392221",
          "shopName": "中心旗舰店(中心旗舰店)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122400077000000002399888",
          "shopName": "服务商已上架已绑定(不勾选01)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015092500077000000001839074",
          "shopName": "测试店铺(123店)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122300077000000002392217",
          "shopName": "利手工冰淇淋(利手工冰淇淋)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015121700077000000002389872",
          "shopName": "海底(上海)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122300077000000002392210",
          "shopName": "desSert(desSert&UU)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126172",
          "shopName": "原浩创2088102146931393(1460796691563)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126170",
          "shopName": "原浩创2088102146931393(1460796690664)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126169",
          "shopName": "原浩创2088102146931393(1460796690399)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126167",
          "shopName": "原浩创2088102146931393(1460796689275)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126171",
          "shopName": "原浩创2088102146931393(1460796691351)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126164",
          "shopName": "原浩创2088102146931393(1460796687525)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126168",
          "shopName": "原浩创2088102146931393(1460796689403)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126166",
          "shopName": "原浩创2088102146931393(1460796688387)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126163",
          "shopName": "原浩创2088102146931393(1460796687396)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126165",
          "shopName": "原浩创2088102146931393(1460796688353)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126157",
          "shopName": "原浩创2088102146931393(1460796684283)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126156",
          "shopName": "原浩创2088102146931393(1460796683338)"
        },
        {
          "categoryId": "",
          "cityCode": "820100",
          "extInfo": {},
          "shopId": "2015122900077000000002409504",
          "shopName": "省市Test"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126155",
          "shopName": "原浩创2088102146931393(1460796683336)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126162",
          "shopName": "原浩创2088102146931393(1460796686389)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126161",
          "shopName": "原浩创2088102146931393(1460796686367)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126173",
          "shopName": "原浩创2088102146931393(1460796692292)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126160",
          "shopName": "原浩创2088102146931393(1460796685222)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126159",
          "shopName": "原浩创2088102146931393(1460796685294)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126174",
          "shopName": "原浩创2088102146931393(1460796692495)"
        },
        {
          "categoryId": "",
          "cityCode": "360400",
          "extInfo": {},
          "shopId": "2016041600077000000003126158",
          "shopName": "原浩创2088102146931393(1460796684295)"
        },
        {
          "categoryId": "",
          "cityCode": "422800",
          "extInfo": {},
          "shopId": "2015122400077000000002393481",
          "shopName": "1231(2)"
        },
        {
          "categoryId": "",
          "cityCode": "341600",
          "extInfo": {},
          "shopId": "2015122400077000000002393484",
          "shopName": "验证审核后的状态(liuye)"
        },
        {
          "categoryId": "",
          "cityCode": "820200",
          "extInfo": {},
          "shopId": "2015122200077000000002390923",
          "shopName": "Test省市区一致"
        },
        {
          "categoryId": "",
          "cityCode": "820200",
          "extInfo": {},
          "shopId": "2015122800077000000002382231",
          "shopName": "1228服务商已绑定已上架(勾选03)"
        },
        {
          "categoryId": "",
          "cityCode": "820200",
          "extInfo": {},
          "shopId": "2015122300077000000002392195",
          "shopName": "中式快餐(中式快餐)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393479",
          "shopName": "原浩创2088102146931393(1450867708595)"
        },
        {
          "categoryId": "",
          "cityCode": "990100",
          "extInfo": {},
          "shopId": "2015050600077000000000080816",
          "shopName": "零食工坊(民生店)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393477",
          "shopName": "原浩创2088102146931393(1450867707733)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393464",
          "shopName": "原浩创2088102146931393(1450867701714)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393478",
          "shopName": "原浩创2088102146931393(1450867708151)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393471",
          "shopName": "原浩创2088102146931393(1450867704962)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393476",
          "shopName": "原浩创2088102146931393(1450867707220)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393470",
          "shopName": "原浩创2088102146931393(1450867704701)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393475",
          "shopName": "原浩创2088102146931393(1450867706620)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393472",
          "shopName": "原浩创2088102146931393(1450867705471)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393474",
          "shopName": "原浩创2088102146931393(1450867706402)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393473",
          "shopName": "原浩创2088102146931393(1450867705822)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393468",
          "shopName": "原浩创2088102146931393(1450867703838)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393469",
          "shopName": "原浩创2088102146931393(1450867704017)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393467",
          "shopName": "原浩创2088102146931393(1450867703020)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393466",
          "shopName": "原浩创2088102146931393(1450867702873)"
        },
        {
          "categoryId": "",
          "cityCode": "530700",
          "extInfo": {},
          "shopId": "2015122300077000000002393465",
          "shopName": "原浩创2088102146931393(1450867701715)"
        },
        {
          "categoryId": "",
          "cityCode": "441900",
          "extInfo": {},
          "shopId": "2016010800077000000002425008",
          "shopName": "POI反查TEst(01)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016110700077000000003446111",
          "shopName": "塔塔美发(03店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016110700077000000003446109",
          "shopName": "塔塔美发(01店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016110700077000000003446110",
          "shopName": "塔塔美发(02店)"
        },
        {
          "categoryId": "",
          "cityCode": "340300",
          "extInfo": {},
          "shopId": "2016030700077000000002881735",
          "shopName": "zxz(zxz)"
        },
        {
          "categoryId": "",
          "cityCode": "340300",
          "extInfo": {},
          "shopId": "2015122500077000000002382223",
          "shopName": "123123(123123)"
        },
        {
          "categoryId": "",
          "cityCode": "340300",
          "extInfo": {},
          "shopId": "2016011800077000000002451028",
          "shopName": "js(注入)"
        },
        {
          "categoryId": "",
          "cityCode": "340300",
          "extInfo": {},
          "shopId": "2015122800077000000002382232",
          "shopName": "1228服务商已绑定已上架(不勾选验证01)"
        },
        {
          "categoryId": "",
          "cityCode": "340300",
          "extInfo": {},
          "shopId": "2015122800077000000002382230",
          "shopName": "1228服务商已上架已绑定(不勾选02)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015122200077000000002392187",
          "shopName": "123123(123123)"
        },
        {
          "categoryId": "",
          "cityCode": "310000",
          "extInfo": {},
          "shopId": "2015050100077000000000039555",
          "shopName": "海底捞肉肉1&TEst"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015110700077000000002125059",
          "shopName": "西贝上海+1446868387327"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015111800077000000002332126",
          "shopName": "shop_1447853399363"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016081000077000000003340533",
          "shopName": "渐隐(行业定制相册)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016011200077000000002425044",
          "shopName": "这小子"
        },
        {
          "categoryId": "",
          "cityCode": "350900",
          "extInfo": {},
          "shopId": "2015122400077000000002399890",
          "shopName": "服务商已上架未绑定(不勾选01)"
        },
        {
          "categoryId": "",
          "cityCode": "230800",
          "extInfo": {},
          "shopId": "2015100900077000000001861878",
          "shopName": "xq测试专用门店"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015122300077000000002393462",
          "shopName": "门店地址TT"
        },
        {
          "categoryId": "",
          "cityCode": "350800",
          "extInfo": {},
          "shopId": "2015042300077000000000011487",
          "shopName": "开心5"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015112000077000000002343605",
          "shopName": "shop_1447956198032"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015112000077000000002343618",
          "shopName": "shop_1447956227767"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015060300077000000000468245",
          "shopName": "海底捞nobankcard(延安店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015060300077000000000468247",
          "shopName": "海底捞nobankcard1(延安店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016030400077000000002845018",
          "shopName": "海底捞(延安店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051400077000000000118368",
          "shopName": "小纨测试，折扣不要动我(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015102300077000000002019103",
          "shopName": "headShopName_1445571375248(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015111900077000000002334902",
          "shopName": "shop_1447905216941"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015120800077000000002377094",
          "shopName": "e(f)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446366",
          "shopName": "headShopName_1478660840554(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015110700077000000002125060",
          "shopName": "西贝上海+1446868390104"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016053100077000000003191871",
          "shopName": "原浩创2088102146931393(1464703298637)"
        },
        {
          "categoryId": "",
          "cityCode": "320100",
          "extInfo": {},
          "shopId": "2015051300077000000000117397",
          "shopName": "零食工坊(雨花南路)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122300077000000002392219",
          "shopName": "蛋糕(蛋糕)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015101000077000000001863404",
          "shopName": "零售商测试(延安店)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122900077000000002412657",
          "shopName": "aaa(dfdfdf)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122300077000000002392197",
          "shopName": "火锅快餐(火锅快餐)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015061500077000000000743974",
          "shopName": "2(菜品测试)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122300077000000002392198",
          "shopName": "奶茶坊(奶茶坊)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446460",
          "shopName": "headShopName_1478679761700(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122400077000000002399889",
          "shopName": "服务商已上架已绑定(勾选002)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015070100077000000001247186",
          "shopName": "2(菜品测试)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015042300077000000000011482",
          "shopName": "开心1"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015061300077000000000669854",
          "shopName": "不要店铺名就填个数字3啊"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015051400077000000000118376",
          "shopName": "萨博(上海店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016051100077000000003167540",
          "shopName": "levy(浦东店)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015061300077000000000669850",
          "shopName": "1(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2016021800077000000002598081",
          "shopName": "pcpl021803(add03)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016080100077000000003329576",
          "shopName": "大白菜测试门店(树村店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016051900077000000003184902",
          "shopName": "headShopName_1463651453404(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015042300077000000000011484",
          "shopName": "开心3"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446458",
          "shopName": "headShopName_1478679669665(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015061300077000000000669853",
          "shopName": "2(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446368",
          "shopName": "消费送礼0元换购"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016082900077000000003383291",
          "shopName": "headShopName_1472441604412(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122900077000000002412658",
          "shopName": "123123(213123)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015121600077000000002388200",
          "shopName": "sd(sds)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015060800077000000000492126",
          "shopName": "1nobank海底捞(延安店)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015061300077000000000669855",
          "shopName": "6(兄弟连)"
        },
        {
          "categoryId": "",
          "cityCode": "110100",
          "extInfo": {},
          "shopId": "2015122300077000000002392213",
          "shopName": "Moo 9(Moo&9)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015051800077000000000120361",
          "shopName": "上海信息大厦店"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446367",
          "shopName": "headShopName_1478660846591(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016111400077000000003447367",
          "shopName": "headShopName_1478596086909(shopName)headShopName_1479115507540(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016080100077000000003329575",
          "shopName": "路人甲测试门店(硅谷亮城店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446457",
          "shopName": "headShopName_1478678640151(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016050300077000000003160900",
          "shopName": "景传ISV切流店8(ISV切流分店8)_ru1zhi_t11111"
        },
        {
          "categoryId": "",
          "cityCode": "120100",
          "extInfo": {},
          "shopId": "2016011400077000000002425072",
          "shopName": "天津省市区"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015092400077000000001829302",
          "shopName": "headShopName_1443073396976(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015051800077000000000120398",
          "shopName": "上海罗山路店"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016050600077000000003167527",
          "shopName": "湘衡(26楼店)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016052600077000000003191638",
          "shopName": "云纵李红红店"
        },
        {
          "categoryId": "",
          "cityCode": "340100",
          "extInfo": {},
          "shopId": "2016061200077000000003218507",
          "shopName": "泛行业(LT001)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410066",
          "shopName": "真功夫12312(黄龙店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410064",
          "shopName": "春天里测试测试"
        },
        {
          "categoryId": "",
          "cityCode": "460200",
          "extInfo": {},
          "shopId": "2016031700077000000002598593",
          "shopName": "服务03(pl03)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016102800077000000003441354",
          "shopName": "瑾瑾美容美发店名字名字超长超长超长超长(02店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016080100077000000003329570",
          "shopName": "凡凡门店01"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016052500077000000003191519",
          "shopName": "瑾凡商超门店(沃尔玛分店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016010500077000000002419723",
          "shopName": "瑾凡门店04(分店4无折扣门店)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016010500077000000002419722",
          "shopName": "瑾凡门店03(%分店03自助买单店)"
        },
        {
          "categoryId": "",
          "cityCode": "280800",
          "extInfo": {},
          "shopId": "2015042300077000000000011483",
          "shopName": "开心2"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016010400077000000002419691",
          "shopName": "瑾凡门店02(分店2)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016030300077000000002831879",
          "shopName": "肯德基百脑汇(百脑汇)"
        },
        {
          "categoryId": "",
          "cityCode": "320400",
          "extInfo": {},
          "shopId": "2016011800077000000002425085",
          "shopName": "qq33(qq)"
        },
        {
          "categoryId": "",
          "cityCode": "621100",
          "extInfo": {},
          "shopId": "2015082400077000000001475832",
          "shopName": "西贝+621100+1440409645580"
        },
        {
          "categoryId": "",
          "cityCode": "120100",
          "extInfo": {},
          "shopId": "2016010800077000000002425010",
          "shopName": "POI反查TEst"
        },
        {
          "categoryId": "",
          "cityCode": "340100",
          "extInfo": {},
          "shopId": "2016031700077000000002598594",
          "shopName": "服务02(pl02)"
        },
        {
          "categoryId": "",
          "cityCode": "320400",
          "extInfo": {},
          "shopId": "2016011800077000000002425084",
          "shopName": "danliu(danliu)"
        },
        {
          "categoryId": "",
          "cityCode": "420800",
          "extInfo": {},
          "shopId": "2015111000077000000002159752",
          "shopName": "咖啡馆9(xq)"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015051300077000000000116408",
          "shopName": "杭州的店铺12"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2016091000077000000003410063",
          "shopName": "海底捞-名字很长很长很长很长很长很长很长"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016082900077000000003383292",
          "shopName": "headShopName_1472441607084(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016082900077000000003383290",
          "shopName": "headShopName_1472441599044(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016082900077000000003383294",
          "shopName": "headShopName_1472441608081(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016082900077000000003383293",
          "shopName": "headShopName_1472441607513(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015101000077000000001863405",
          "shopName": "零售商test3(延安店2)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016052000077000000003186302",
          "shopName": "headShopName_1463711498033(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016052000077000000003186301",
          "shopName": "headShopName_1463711207883(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2015051800077000000000120316",
          "shopName": "上海进才中学店"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016110900077000000003446459",
          "shopName": "headShopName_1478679696851(shopName)"
        },
        {
          "categoryId": "",
          "cityCode": "310100",
          "extInfo": {},
          "shopId": "2016083100077000000003397921",
          "shopName": "丽人美甲02（泛行业）"
        },
        {
          "categoryId": "",
          "cityCode": "310000",
          "extInfo": {},
          "shopId": "2015050100077000000000039556",
          "shopName": "海底捞肉肉2"
        },
        {
          "categoryId": "",
          "cityCode": "330100",
          "extInfo": {},
          "shopId": "2015052200077000000000194415",
          "shopName": "小纨测试商家相册啦啦(黄龙店啦啦啦）"
        }
      ]
    });
  },
  'GET /promo/conponsVerify/operatorsQuery.json': function(req, res) { //查询操作员
    this.request = {
      data: {shopId: '2015052200077000000000194415'},
    }
  }, //有报错
  'GET /promo/conponsVerify/conponsQuery.json': function(req, res) { //券查询接口
    this.request = {
      data: {
        shopId: '2015051200077000000000109858',
        conponId: '60000950',
      },
    }
    res.json({});
  },
  'GET /promo/conponsVerify/conponsVerify.json': function(req, res) { // 券核销
    this.request = {
      data: {
        shopId: '2015051200077000000000109858',
        conponId: '60000950',
      },
    }
    res.json({});
  },
  'GET /promo/conponsVerify/verifyRecordsQuery.json': function(req, res) { // 券核销记录接口
    this.request = {
      data: {
        shopId: '2015052200077000000000194415',
        operatorId: '',
        pageIndex: 1,
        pageSize: 10,
        conponId: '',
      },
    };
    res.json({
      "data": [
        {
          "verifyNo": "123456789123456",
          "operatorType": "MERCHANT",
          "operatorId": "2088102147265233",
          "status": "SUCCESS",
          "id": 60000950,
          "recordNo": "39201610180015500900106000095039",
          "description": "wqqwwqwq",
          "shopId": "2015051200077000000000109858",
          "voucherName": "汉堡兑换券",
          "verifyTime": "Tue Oct 18 03:15:12 CST 2016",
          "userId": "2088102139933377",
          "extInfo": {
            "name": "levy"
          },
          "merchantId": "2088102146931393"
        }
      ],
      "page": {
        "pageSize": 0,
        "currentPage": 10,
        "totalSize": 1
      },
      "status": "success"
    });
  }
};

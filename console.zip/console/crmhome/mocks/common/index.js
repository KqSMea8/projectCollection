module.exports = {
  'GET /shop/alive.json': function(req, res) {
    res.statusCode = 200;
    res.end();
  }
};

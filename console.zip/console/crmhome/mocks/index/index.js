module.exports = {
  'GET /queryIndexDataView.json': function(req, res) {
    res.json({
    "newsView": {
      "list": [
        {
          "bizType": "9",
          "content": "????????????204??????????3?",
          "createTime": "2016-04-13",
          "extInfo": "support/entry.htm#/punish/result/8211111984",
          "fromMerchantId": " ",
          "id": 355281,
          "status": "2",
          "subTitle": "????????",
          "title": "????????????204??????????3?",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-10",
          "fromMerchantId": "2088101159953541",
          "id": 6137,
          "status": "2",
          "title": "???????4???????2015-10-13?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-10",
          "fromMerchantId": "2088101159953541",
          "id": 6135,
          "status": "2",
          "title": "???????4???????2015-10-15?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-10",
          "fromMerchantId": "2088101159953541",
          "id": 6133,
          "status": "2",
          "title": "???????hehe???????2015-10-15?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-09",
          "fromMerchantId": "2088101159953541",
          "id": 6123,
          "status": "2",
          "title": "???????4???????2015-10-14?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-09",
          "fromMerchantId": "2088101159953541",
          "id": 6117,
          "status": "2",
          "title": "???????y12345698???????45@@???????2015-10-14?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-09",
          "fromMerchantId": "2088101159953541",
          "id": 6104,
          "status": "2",
          "title": "???????3???????2015-10-14?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-09",
          "fromMerchantId": "2088101159953541",
          "id": 6096,
          "status": "2",
          "title": "???????2???????2015-10-14?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-08",
          "fromMerchantId": "2088101160121447",
          "id": 6093,
          "status": "2",
          "title": "xynuvv???????????????2015-10-08?????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        },
        {
          "bizType": "2",
          "content": "",
          "createTime": "2015-10-08",
          "fromMerchantId": "2088101159953541",
          "id": 6089,
          "status": "2",
          "title": "??????????ab1de?????abcde????@?????????2015-10-13??????????????????",
          "toMerchantId": "2088102146159401",
          "type": "1"
        }
      ]
    },
    "promoView": {},
    "status": "succeed"
    });
  },
};

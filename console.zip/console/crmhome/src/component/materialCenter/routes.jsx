import MaterialCenter from './index';

export default [
  {
    path: 'material/center',
    component: MaterialCenter,
  },
];

import KaContract from './index';

export default [{
  path: 'contract',
  component: KaContract,
}];

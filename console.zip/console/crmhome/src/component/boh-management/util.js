export const urlCreateSimpleShop = '/shop.htm?mode=create#/simpleshop/create';
export const getUrlUpgradeShop = (shopId) => {
  return `/shop.htm?mode=modify#/shop/edit/${shopId}/upgrade`;
};

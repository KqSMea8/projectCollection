import './style.less';

export GroupsAddName from './name';
export GroupsAddBasic from './basic';
export GroupAddIndustry from './industry';
export GroupsAddSubmit from './submit';
export GroupsAddConsumer from './consumer';
export GroupsAddLocation from './location';
export GroupAddThird from './third';
export convert from './convert';
export validate from './validate';
export filter from './filter';
export GroupCustomerDivide from './divide';
export GroupsAddTarget from './target';

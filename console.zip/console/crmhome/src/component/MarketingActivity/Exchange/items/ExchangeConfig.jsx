export const itemLayout = {
  labelCol: { span: 4, offset: 2 },
  wrapperCol: { span: 12 },
};

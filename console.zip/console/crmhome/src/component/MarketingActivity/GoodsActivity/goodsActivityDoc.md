### 服务商操作通知跳转地址规则：

- 创建

http://crmhome-d0099.alipay.net/main.htm#/marketing-activity/goods/detail/:id/create

- 修改

http://crmhome-d0099.alipay.net/main.htm#/marketing-activity/goods/detail/:id/edit


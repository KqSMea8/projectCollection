import React from 'react';

/**
 * 口碑报名 - 商品活动 - 口碑活动详情
 *
 */

const OtherRedirect = React.createClass({
  getInitialState() {
    window.location.pathname = `/goods/itempromo/promotion.htm`;
  },
  render() {
    return null;
  },
});

export default OtherRedirect;

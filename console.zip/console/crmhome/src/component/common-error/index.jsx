import React from 'react';
import './index.less';

export default class CommonError extends React.Component {

  componentDidMount() {
  }

  render() {
    return (
      <div>
       error
      </div>
    );
  }
}
